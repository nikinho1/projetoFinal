from django.contrib import admin
from django.urls import path, include
from .views import home, about, fags

urlpatterns = [
    path('index.html', home),
    path('about.html', about),
    path('fags.html', fags)
]